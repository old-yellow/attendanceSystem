import { Hero } from './domain/hero';

export const HEROES: Hero[] = [
    {  comment: 'ACDIT',
    userId:'0',
    leaveTime: "2018-10-01",
    askTime: "2018-08-01",
    leaveCatagoryID: "1",
    leaveReason: "世界那么大" }
];