export class Hero {
    comment:string;
    userId: string;
     leaveTime:string;
    askTime: string;
     leaveCatagoryID: string;
     leaveReason: string;
}